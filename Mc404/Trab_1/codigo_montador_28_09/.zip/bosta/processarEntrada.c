#include "montador.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void trim();
int check_end_line();
void capturar_palavra();
void processa_palavra();

/* 
 * Argumentos:
 *  entrada: cadeia de caracteres com o conteudo do arquivo de entrada.
 *  tamanho: tamanho da cadeia.
 * Retorna:
 *  1 caso haja erro na montagem; 
 *  0 caso não haja erro.
 */
int processarEntrada(char* entrada, unsigned tamanho) 
{
    /* Index da entrada */
    int ie = 0;
    /* Linha de codigo atual */
    int linha = 1;

    int i;  
    /* todo: verificar <= ou < */
    while(ie < tamanho - 1) {

        /* Pulando espacos em brancos e \n com a soma da linha autal */
        do {
            trim(entrada, &ie);
        } while(check_end_line(entrada, tamanho, &ie, &linha));
       
        /* Captura a proxima palavra a ser lida */ 
        char *palavra = malloc(sizeof(char)*(tamanho - ie + 1));
        capturar_palavra(entrada, tamanho, &ie, palavra, &linha);

        processa_palavra(palavra, linha);
    }

    int n_tokens = getNumberOfTokens(); 
    Token t;
    
    int found_rotulo = 0;
    for(i = 0; i < n_tokens; i++) {
        t = recuperaToken(i);
        if(t.tipo == DefRotulo) {
            if(found_rotulo == 1) {
                printf("ERRO GRAMATICAL: palavra na linha %d!\n", t.linha); 
                return 0;
            } else {
                found_rotulo = 1;
            }
        }
        
    }
    /* todo: free nas palavras nos tokens no final da execucao */
    imprimeListaTokens();
    return 0; 
}

void processa_palavra(char *palavra, int linha) {

    int tam = strlen(palavra);
    int n_last = tam-1;
    char c_last = palavra[n_last];
    char c_first = palavra[0];
    int n_tokens = getNumberOfTokens();
    Token last_token; 
    Token penul_token;

    if(n_tokens > 0) {
        last_token = recuperaToken(n_tokens-1);
        if(n_tokens > 1) {
            penul_token = recuperaToken(n_tokens-2);
        }
    }
    int i;
    /* todo: tratamento de erro */
    
    Token novo_token;
    
    novo_token.linha = linha;
    
    if(c_first == '"' && c_last == '"') {
        for(i = 0; i < tam - 2; i++) {
            palavra[i] = palavra[i+1]; 
        }
        palavra[tam-2] = '\0'; 
    }

    novo_token.palavra = palavra; 
   
    /* A palavra eh uma diretiva */
    if(c_first == '.') {
        novo_token.tipo = Diretiva; 
        adicionarToken(novo_token);
    }
    /* Caso seja um termo entre aspas */ 
    else if(c_first == '"' && c_last == '"') {
        /* Eh um numero entre aspas */
        if(isdigit(palavra[0])) {
            /* Eh um hexadecimal */
            if(palavra[1] == 'x') {
                novo_token.tipo = Hexadecimal;
                adicionarToken(novo_token);
            }
            /* Eh um decimal */
            else {
                novo_token.tipo = Decimal;
                adicionarToken(novo_token);
            }
        }
        /* Eh um nome */
        else {
            novo_token.tipo = Nome;
            adicionarToken(novo_token);
        }
    }
    
    /* A palavra eh um rotulo */
    else if(c_last == ':') {
        novo_token.tipo = DefRotulo;
        adicionarToken(novo_token);
    }
    /* A palavra eh um comentario */
    else if(c_first == '#') {
       /* Else meio bobo, porque comentarios nao sao adicionados */ 
    }
    else if(!strcmp(palavra, "LOAD")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);
    }
    else if(!strcmp(palavra, "LOAD-")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "LOAD|")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "LOADmq")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "LOADmq_mx")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "STOR")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "JUMP")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "JMP+")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "ADD")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "ADD|")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "SUB")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "SUB|")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "MUL")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "DIV")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "LSH")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "RSH")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    else if(!strcmp(palavra, "STORA")) {
        novo_token.tipo = Instrucao;
        adicionarToken(novo_token);

    }
    /* Temos um candidado a numero */
    else if(isdigit(c_first)) {
        /* Numero em hexadecimal  */
        if(palavra[1] == 'x') {
            novo_token.tipo = Hexadecimal;
            adicionarToken(novo_token); 
        }
        /* Numero em decimal */
        else {
            novo_token.tipo = Decimal;
            adicionarToken(novo_token);
        } 
    }
    else if(last_token.tipo == Diretiva) {
        novo_token.tipo = Nome;
        adicionarToken(novo_token);
    }
    else if(penul_token.tipo == Diretiva) {
        novo_token.tipo = Nome;
        adicionarToken(novo_token);
    }
}

void trim(char *entrada, int *ie) {
    while(entrada[*ie] == ' ') {
        *ie += 1;
    }
}

/* 
 * Argumentos:
 *  entrada: cadeia de caracteres com o conteudo do arquivo de entrada.
 *  tamanho: tamanho da cadeia.
 *  ie: ponteiro para o index atual a ser lido da cadeia
 *  linha: ponteiro para a linha atual
 * Retorno: 
 * 1 caso seja encontrado um fim de linha;
 * 0 caso nao seja encontrado um fim de linha.
 */
int check_end_line(char *entrada, int tamanho, int *ie, int *linha) {
    /* todo: checar se eu nao estou comendo ou colocando uma linha */
    if(entrada[*ie] == '\n') {
        *linha += 1;
        *ie += 1;
        return 1;
    }
    else {
        return 0;
    }
}

/* 
 * Argumentos:
 *
 *  palavra: buffer de tamanho no maximo (tamanho - ie) caracteres 
 *  entrada: cadeia de caracteres com o conteudo do arquivo de entrada.
 *  tamanho: tamanho da cadeia.
 *  linha: ponteiro para o numero da linha atual.
 *  ie: ponteiro para o index atual a ser lido da cadeia.
 */
void capturar_palavra(char *entrada, int tamanho, int *ie, char *palavra, 
                      int *linha) {
    int ip = 0; 

    /*todo: erros ocorrem ao encontrar # ou . no meio de palavras */

    /* Encontrei uma diretiva no inicio */
    if(entrada[*ie] == '.') {
        /* Trata a leitura da diretiva ate o seu fim */
        while(entrada[*ie] != ' ') {
            palavra[ip] = entrada[*ie];
            *ie += 1;
            ip += 1;
        }
        *ie += 1;
        
    } 
    /* Encontrei um comentario no inicio */
    else if(entrada[*ie] == '#') {
        /* Trata a leitura do comentario ate o seu fim */
        while(entrada[*ie] != '\n') {
            palavra[ip] = entrada[*ie];
            *ie += 1;
            ip += 1;
        }
    }
    /* Pode ser um rotulo ou uma instrucao */
    else {
        /* Leia a palavra ate o final ou um : e testa se era rotulo ou uma 
         * instrucao */
        while(entrada[*ie] != ':' 
                 && entrada[*ie] != ' '
                    && entrada[*ie] != '\n') {
            palavra[ip] = entrada[*ie];
            *ie += 1;
            ip += 1;
        }
       
        /* Colocando o simbolo de rotulo para facilitar identificacao*/ 
        if(entrada[*ie] == ':') {
            palavra[ip] = ':';
            ip++;
        }

        if(entrada[*ie] != '\n') {
            *ie += 1;
        } 
    }
    /* Pulando o caracter de parada dos loops de leitura */
    palavra[ip] = '\0';

}
