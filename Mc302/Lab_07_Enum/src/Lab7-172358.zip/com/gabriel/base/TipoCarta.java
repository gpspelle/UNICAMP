package com.gabriel.base;

public enum TipoCarta {
    LACAIO, BUFF, DANO, DANO_AREA;
}
