Gabriel Pellegrino da Silva/ 172358

Segundo laborátorio de Mc302. 
Aprimoramento do primeiro laboratorio, sobrecarga de construtores e re-utiliza
cao de codigo, alem de utilizacao dos metodos get() e set();
