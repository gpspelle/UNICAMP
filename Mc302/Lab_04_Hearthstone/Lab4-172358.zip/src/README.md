Gabriel Pellegrino da Silva/ 172358

Quarto laborátorio de Mc302. 
Aprimoramento do terceiro laboratorio, agora o baralho suporta varios tipos de 
carta, temos novas cartas que aplicam 'magias', sobrescrita e sobrecarga de me
todos. 
Sobrescrita: especializar um metodo da superclasse nas subclasses;
Sobrecarga: lista de parametros diferentesdiferentes para um metodo com a mesma
chamada, podendo levar a comportamentos diferentes.
