javac -d . Main.java
java Main
