Gabriel Pellegrino da Silva/ 172358

Acredito que mandei coisas a mais do que o necessario, eu so preciso mandar os
arquivos .java? 

Terceiro laborátorio de Mc302. 
Aprimoramento do segundo laboratorio, agora foi padronizado o metodo buffar,tam-
bem temos duas estruturas de dados para um baralho, a possibilidade de comprar 
cartas, adicionar cartas e embaralhar o baralho. 

Este laboratorio foi realizado com um editor de texto e o terminal gnu/LINUX.
Logo, para compilar o programa e executa-lo foi utilizado um script 'compiler.sh'

Para utilizar, realizei 

    chmod +x compiler.sh                        //dar permissao para o script
    ./compiler.sh 	                        //executar o script

Espero que isso nao cause problemas na correcao.
