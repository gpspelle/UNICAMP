Gabriel Pellegrino da Silva/ 172358

Sexto laborátorio de Mc302.
 
Aprendendo a utilizar Collections: parece muito útil para resolver problemas de busca e combinações(poderia ter sido utilizado no trabalho 1).

