Gabriel Pellegrino da Silva/ 172358

Oitavo laborátorio de Mc302.

Uso de interfaces, classes abstratas e divisão infinita em packages: gostei. 
 

