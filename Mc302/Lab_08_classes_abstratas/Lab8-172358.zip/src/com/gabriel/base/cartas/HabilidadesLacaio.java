package com.gabriel.base.cartas;

public enum HabilidadesLacaio {
    EXAUSTAO, PROVOCAR, INVESTIDA;
}
