package com.gabriel.util;

public abstract class Util {

    public static final int PODER_HEROI = 10;
    public static final int MAX_CARDS = 30;
    public static final int MAO_INI = 10;

}
