/*  Gabriel Pellegrino da Silva /172358
    Laboratório 8 :
*/

import com.gabriel.base.*;
import com.gabriel.base.cartas.*;
import com.gabriel.base.controle.Controle;
import com.gabriel.base.service.impl.ProcessadorServiceImpl;
import com.gabriel.util.Util;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Controle controle = new Controle();
        controle.executa();
    }
}
