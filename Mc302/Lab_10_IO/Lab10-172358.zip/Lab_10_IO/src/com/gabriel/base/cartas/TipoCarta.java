package com.gabriel.base.cartas;

public enum TipoCarta {
    LACAIO, BUFF, DANO, DANO_AREA;
}
