Gabriel Pellegrino da Silva/ 172358

Decimo laborátorio de Mc302.

Uso de serializables. Duvida: posso implementar a mi-
nha serializacao como foi feito ou posso utilizar algo
pronto, feito pela linguagem?
